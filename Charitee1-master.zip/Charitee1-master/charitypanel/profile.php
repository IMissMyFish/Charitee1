<!DOCTYPE html>

<html>
 //charity panel
<head>
  <title>Charitee</title>
  <link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,500,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
  <link  rel = "stylesheet" type = "text/css"  href = "./standard.css">
</head>

<body>
    <div id = "logoSec">
      <img id = "logo" src="./white_logo_transparent.png">  
  </div>


  <figure class="tint">
    <img id = "bgImg" src="background.jpg">
  </figure>

</body>

<foot>
</foot>

</html>

A Pen created at CodePen.io. You can find this one at https://codepen.io/FadilE/pen/myQeve.

 This is a quiz or survey depending on the questions being asked.